export const selectUserId = (state) => state.user.userId;
export const selectVisitCounts = (state) => state.user.visitCounts;
export const selectUserType = (state) => state.user.userType;