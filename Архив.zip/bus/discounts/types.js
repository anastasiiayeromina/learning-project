export const types = {
  FILL_DISCOUNTS: 'FILL_DISCOUNTS',
};