export const types = {
  FILL_NEWS: 'FILL_NEWS',
};