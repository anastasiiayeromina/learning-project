export const types = {
  FILL_CARS: 'FILL_CARS',
};