// Actions

export const initialDispatcher = async (context, store) => {
  // store.dispatch();

  return store;
}

